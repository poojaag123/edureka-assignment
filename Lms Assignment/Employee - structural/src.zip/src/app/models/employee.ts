export interface Employee {
  employeeID: Number;
  firstName: String;
  lastName: String;
  salary: Number;
  dob: Date;
  email: String;
}
